#!/bin/bash
systemctl reset-failed web.service || true
systemctl restart web.service || true
